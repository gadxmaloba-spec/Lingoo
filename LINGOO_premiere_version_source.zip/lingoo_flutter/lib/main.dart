import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const LingooApp());
}

class LingooApp extends StatefulWidget {
  const LingooApp({super.key});
  @override
  State<LingooApp> createState() => _LingooAppState();
}

class _LingooAppState extends State<LingooApp> {
  Locale _locale = const Locale('fr');

  void changeLocale(Locale locale) => setState(() => _locale = locale);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'LINGOO',
      locale: _locale,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2878D0),
          primary: const Color(0xFF2878D0),
          secondary: const Color(0xFFFFC83D),
          surface: const Color(0xFFF7F9FC),
        ),
        scaffoldBackgroundColor: const Color(0xFFF7F9FC),
        fontFamily: 'Roboto',
      ),
      home: LingooHome(onLocaleChanged: changeLocale, locale: _locale),
    );
  }
}

class LingooHome extends StatefulWidget {
  const LingooHome({super.key, required this.onLocaleChanged, required this.locale});
  final ValueChanged<Locale> onLocaleChanged;
  final Locale locale;

  @override
  State<LingooHome> createState() => _LingooHomeState();
}

class _LingooHomeState extends State<LingooHome> {
  String targetLanguage = 'Anglais';
  int xp = 0;
  bool remindersEnabled = true;

  static const languages = [
    'Anglais', 'Français', 'Espagnol', 'Allemand', 'Italien',
    'Portugais', 'Arabe', 'Chinois', 'Japonais', 'Coréen',
    'Bengali', 'Hindi', 'Russe', 'Néerlandais', 'Turc',
    'Swahili', 'Grec', 'Polonais', 'Suédois', 'Indonésien',
  ];

  bool get isEnglish => widget.locale.languageCode == 'en';
  String t(String fr, String en) => isEnglish ? en : fr;

  @override
  void initState() {
    super.initState();
    _loadProgress();
  }

  Future<void> _loadProgress() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      xp = prefs.getInt('xp') ?? 0;
      targetLanguage = prefs.getString('targetLanguage') ?? 'Anglais';
      remindersEnabled = prefs.getBool('remindersEnabled') ?? true;
    });
  }

  Future<void> _saveProgress() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('xp', xp);
    await prefs.setString('targetLanguage', targetLanguage);
    await prefs.setBool('remindersEnabled', remindersEnabled);
  }

  void _completeLesson() {
    setState(() => xp += 10);
    _saveProgress();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(t('Bravo ! 🎉', 'Great job! 🎉')),
        content: Text(t('Tu as terminé la leçon et gagné 10 XP.', 'You completed the lesson and earned 10 XP.')),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        titleSpacing: 18,
        title: Row(children: [
          const CatMark(),
          const SizedBox(width: 9),
          const Text('LINGOO', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
        ]),
        actions: [
          IconButton(
            tooltip: t('Paramètres', 'Settings'),
            onPressed: _showSettings,
            icon: const Icon(Icons.settings_outlined),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 28),
          children: [
            Row(
              children: [
                Expanded(child: Text(t('Prêt à apprendre ?', 'Ready to learn?'),
                  style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900))),
                _pill(Icons.star_rounded, '$xp XP', const Color(0xFFFFC83D)),
              ],
            ),
            const SizedBox(height: 7),
            Text(t('Chaque jour est une nouvelle occasion de progresser.',
                'Every day is a new chance to improve.'),
              style: TextStyle(color: Colors.grey.shade700, fontSize: 14)),
            const SizedBox(height: 22),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF2878D0), Color(0xFF55A4E8)],
                  begin: Alignment.topLeft, end: Alignment.bottomRight),
                borderRadius: BorderRadius.circular(24),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(t('TA LANGUE', 'YOUR LANGUAGE'),
                  style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                const SizedBox(height: 7),
                Row(children: [
                  const Text('🌍', style: TextStyle(fontSize: 31)),
                  const SizedBox(width: 10),
                  Expanded(child: Text(targetLanguage,
                    style: const TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.w900))),
                  IconButton(
                    onPressed: _chooseLanguage,
                    icon: const Icon(Icons.edit, color: Colors.white),
                    tooltip: t('Changer de langue', 'Change language'),
                  )
                ]),
                Text(t('Une petite leçon à la fois.', 'One small lesson at a time.'),
                  style: const TextStyle(color: Colors.white)),
              ]),
            ),
            const SizedBox(height: 22),
            Text(t('Ton parcours', 'Your learning path'),
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            _lessonCard(
              number: '01',
              title: t('Les salutations', 'Greetings'),
              subtitle: t('Dire bonjour et se présenter', 'Say hello and introduce yourself'),
              icon: Icons.waving_hand_rounded,
              color: const Color(0xFFFFC83D),
              onTap: _openLesson,
            ),
            const SizedBox(height: 12),
            _lessonCard(
              number: '02',
              title: t('Les mots essentiels', 'Essential words'),
              subtitle: t('Apprends tes premiers mots', 'Learn your first words'),
              icon: Icons.menu_book_rounded,
              color: const Color(0xFF8CCFAD),
              locked: true,
              onTap: () => _lockedMessage(),
            ),
            const SizedBox(height: 22),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
              child: Row(children: [
                const Icon(Icons.wifi_off_rounded, size: 28, color: Color(0xFF2878D0)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(t('Apprentissage hors ligne', 'Offline learning'),
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 3),
                  Text(t('Cette leçon de démonstration fonctionne sans Internet.',
                      'This demo lesson works without an internet connection.'),
                    style: TextStyle(color: Colors.grey.shade700, fontSize: 12)),
                ]))
              ]),
            ),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        destinations: [
          NavigationDestination(icon: const Icon(Icons.school_outlined), label: t('Apprendre', 'Learn')),
          NavigationDestination(icon: const Icon(Icons.emoji_events_outlined), label: t('Classement', 'League')),
          NavigationDestination(icon: const Icon(Icons.person_outline), label: t('Profil', 'Profile')),
        ],
        onDestinationSelected: (index) {
          if (index != 0) {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text(t('Cette partie arrive bientôt.', 'This section is coming soon.'))));
          }
        },
      ),
    );
  }

  Widget _pill(IconData icon, String label, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
    decoration: BoxDecoration(color: color.withOpacity(.22), borderRadius: BorderRadius.circular(30)),
    child: Row(children: [Icon(icon, size: 18), const SizedBox(width: 4),
      Text(label, style: const TextStyle(fontWeight: FontWeight.w900))]),
  );

  Widget _lessonCard({required String number, required String title, required String subtitle,
    required IconData icon, required Color color, required VoidCallback onTap, bool locked = false}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
        child: Row(children: [
          Container(width: 52, height: 52, decoration: BoxDecoration(color: color.withOpacity(.28),
            borderRadius: BorderRadius.circular(16)), child: Icon(icon, size: 27)),
          const SizedBox(width: 13),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('$number  ·  $title', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
            const SizedBox(height: 4),
            Text(subtitle, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
          ])),
          Icon(locked ? Icons.lock_outline : Icons.arrow_forward_ios_rounded, size: 18),
        ]),
      ),
    );
  }

  void _chooseLanguage() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => SafeArea(child: SizedBox(
        height: MediaQuery.of(ctx).size.height * .72,
        child: Column(children: [
          Padding(padding: const EdgeInsets.all(18), child: Text(t('Choisis une langue', 'Choose a language'),
            style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20))),
          Expanded(child: ListView.builder(
            itemCount: languages.length,
            itemBuilder: (_, i) => ListTile(
              leading: const Icon(Icons.language),
              title: Text(languages[i]),
              trailing: targetLanguage == languages[i] ? const Icon(Icons.check_circle, color: Colors.green) : null,
              onTap: () {
                setState(() => targetLanguage = languages[i]);
                _saveProgress();
                Navigator.pop(ctx);
              },
            ),
          )),
        ]),
      )),
    );
  }

  void _openLesson() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => LessonPage(
      isEnglish: isEnglish, onComplete: _completeLesson)));
  }

  void _lockedMessage() => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(t('Termine la première leçon pour continuer.', 'Finish the first lesson to continue.'))));

  void _showSettings() {
    showModalBottomSheet(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) =>
      SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(
        mainAxisSize: MainAxisSize.min, children: [
          Text(t('Paramètres', 'Settings'), style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          ListTile(
            leading: const Icon(Icons.translate),
            title: Text(t('Langue de l’application', 'App language')),
            subtitle: Text(isEnglish ? 'English' : 'Français'),
            trailing: DropdownButton<String>(
              value: isEnglish ? 'English' : 'Français',
              items: const [DropdownMenuItem(value: 'Français', child: Text('Français')),
                DropdownMenuItem(value: 'English', child: Text('English'))],
              onChanged: (v) {
                if (v != null) widget.onLocaleChanged(Locale(v == 'English' ? 'en' : 'fr'));
                Navigator.pop(ctx);
              },
            ),
          ),
          SwitchListTile(
            value: remindersEnabled,
            onChanged: (v) {
              setState(() => remindersEnabled = v);
              setSheet(() {});
              _saveProgress();
            },
            secondary: const Icon(Icons.notifications_active_outlined),
            title: Text(t('Rappels', 'Reminders')),
            subtitle: Text(t('Activer les rappels d’apprentissage', 'Enable learning reminders')),
          ),
          const SizedBox(height: 8),
          Text(t('Les notifications programmées seront activées dans la prochaine étape.',
            'Scheduled notifications will be enabled in the next step.'),
            style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
        ],
      )))));
  }
}

class LessonPage extends StatefulWidget {
  const LessonPage({super.key, required this.isEnglish, required this.onComplete});
  final bool isEnglish;
  final VoidCallback onComplete;
  @override
  State<LessonPage> createState() => _LessonPageState();
}

class _LessonPageState extends State<LessonPage> {
  int selected = -1;
  bool checked = false;

  @override
  Widget build(BuildContext context) {
    final en = widget.isEnglish;
    return Scaffold(
      appBar: AppBar(title: Text(en ? 'Lesson 1 · Greetings' : 'Leçon 1 · Salutations')),
      body: Padding(padding: const EdgeInsets.all(22), child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          LinearProgressIndicator(value: checked ? 1 : .5, minHeight: 8,
            borderRadius: BorderRadius.circular(20)),
          const SizedBox(height: 28),
          Text(en ? 'What does “Hello” mean?' : 'Que signifie « Hello » ?',
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          const SizedBox(height: 20),
          ...[
            en ? 'Goodbye' : 'Au revoir',
            en ? 'Bonjour' : 'Hello',
            en ? 'Thank you' : 'Merci',
          ].asMap().entries.map((entry) {
            final i = entry.key;
            return Padding(padding: const EdgeInsets.only(bottom: 12), child: OutlinedButton(
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.all(18),
                backgroundColor: selected == i ? const Color(0xFFE5F1FF) : Colors.white,
                side: BorderSide(color: selected == i ? const Color(0xFF2878D0) : Colors.black12, width: 1.5),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
              onPressed: checked ? null : () => setState(() => selected = i),
              child: Align(alignment: Alignment.centerLeft, child: Text(entry.value,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
            ));
          }),
          const Spacer(),
          if (checked)
            Text(en ? 'Correct! +10 XP' : 'Bonne réponse ! +10 XP',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.green, fontWeight: FontWeight.w900, fontSize: 17)),
          const SizedBox(height: 12),
          FilledButton(
            style: FilledButton.styleFrom(padding: const EdgeInsets.all(17),
              backgroundColor: const Color(0xFF2878D0)),
            onPressed: selected == -1 ? null : () {
              if (selected == 1) {
                setState(() => checked = true);
                widget.onComplete();
              } else {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text(en ? 'Try again!' : 'Essaie encore !')));
              }
            },
            child: Text(checked ? (en ? 'Done' : 'Terminé') : (en ? 'Check answer' : 'Vérifier')),
          ),
        ],
      )),
    );
  }
}

class CatMark extends StatelessWidget {
  const CatMark({super.key});
  @override
  Widget build(BuildContext context) => Container(
    width: 38, height: 38,
    decoration: BoxDecoration(color: const Color(0xFFFFC83D), borderRadius: BorderRadius.circular(13)),
    child: const Center(child: Text('🐱', style: TextStyle(fontSize: 24))),
  );
}
