# LINGOO — première version Flutter

Cette archive contient le **prototype source** de LINGOO : une application Android en français/anglais, avec sélection de 20 langues à apprendre, une leçon de démonstration hors ligne et sauvegarde locale des XP/préférences.

## Important
Ce dossier est le code source Flutter, **pas encore un APK installable**. Il faut Flutter et Android Studio pour générer l'APK. Les notifications sont prévues dans les dépendances et l'interface de réglages, mais la programmation réelle des notifications et Firebase seront ajoutées dans une prochaine étape.

## Lancer le projet
1. Installer Flutter et Android Studio sur un ordinateur.
2. Dans ce dossier, exécuter `flutter create .`
3. Exécuter `flutter pub get`
4. Brancher un téléphone Android avec le débogage USB activé ou démarrer un émulateur.
5. Exécuter `flutter run`

## Générer un APK
Exécuter `flutter build apk --release`. Le fichier sera créé dans `build/app/outputs/flutter-apk/app-release.apk`.

## Prochaine étape
Ajouter les notifications locales programmées, puis Firebase (comptes, synchronisation et notifications à distance). Les classements, profils, paiement Premium et leçons complètes ne sont pas encore implémentés.
